"""Compose measured native Brush renders into a comparison sheet and preview."""
import json
import shutil
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
source = root / 'inputs/gaussian-terrain-reference'
native = root / 'outputs/render-native-retry/views/eval_1'
out = root / 'outputs/deliverables'
out.mkdir(exist_ok=False)
frames = root / 'outputs/video-frames'
frames.mkdir(exist_ok=False)
font_path = '/System/Library/Fonts/Supplemental/Arial.ttf'
def font(size):
    return ImageFont.truetype(font_path, size)
def reference(path):
    image = Image.open(path).convert('RGBA')
    black = Image.new('RGBA', image.size, (0,0,0,255))
    return Image.alpha_composite(black, image).convert('RGB')
def panel(canvas, image, box):
    x,y,w,h = box
    image = image.convert('RGB')
    scale = min(w/image.width,h/image.height)
    resized = image.resize((round(image.width*scale),round(image.height*scale)),Image.Resampling.LANCZOS)
    canvas.paste(resized,(x+(w-resized.width)//2,y+(h-resized.height)//2))

sheet = Image.new('RGB',(1068,1180),(17,21,23))
d=ImageDraw.Draw(sheet)
d.text((28,24),'Terrain learned on Apple M4',font=font(31),fill='white')
d.text((28,66),'Brush 0.3.0  |  2,000 steps  |  12,000 Gaussians  |  24 training views',font=font(19),fill=(179,195,185))
d.text((28,98),'Four held-out cameras. Mean native PSNR 32.36 dB; SSIM 0.908.',font=font(18),fill=(216,222,219))
for x,label in [(52,'Cycles reference'),(389,'2-step pilot'),(726,'2,000-step learned')]:
    d.text((x,145),label,font=font(22),fill='white')
for i in range(4):
    y=180+i*236
    for x,path,is_ref in [(28,source/f'dataset/images/val_{i:03}.png',True),
                          (365,root/f'outputs/pilot-2steps/training/eval_2/val_{i:03}.png',False),
                          (702,root/f'outputs/train-2000/training/eval_2000/val_{i:03}.png',False)]:
        d.rectangle((x,y,x+310,y+208),fill='black')
        panel(sheet,reference(path) if is_ref else Image.open(path),(x,y,310,208))
    d.text((28,y+211),f'Held-out camera {i+1}',font=font(16),fill=(161,171,167))
d.text((28,1136),'192 x 192 source/evaluation images, enlarged for display. Learned splats are native Brush renders.',font=font(16),fill=(172,182,177))
sheet.save(out/'terrain-heldout-comparison.png')
shutil.copy2(root/'outputs/train-2000/training/export_2000.ply',out/'terrain-trained-2000.ply')

def base(label,subtitle):
    image=Image.new('RGB',(960,720),(14,18,20));draw=ImageDraw.Draw(image)
    draw.text((30,22),'Terrain Gaussian splats | learned on Apple M4',font=font(27),fill='white')
    draw.text((30,60),'2,000 steps  |  12,000 learned Gaussians  |  Brush 0.3.0',font=font(19),fill=(178,200,187))
    draw.text((30,100),label,font=font(24),fill='white')
    draw.text((30,652),subtitle,font=font(17),fill=(190,199,194))
    draw.text((30,683),'Offline native renders. Training captures: 192 x 192. This is the isolated patch.',font=font(16),fill=(139,154,146))
    return image

index=0
def emit(image,count):
    global index
    for _ in range(count):
        image.save(frames/f'{index:04}.png')
        index+=1
for i in range(72):
    image=base('Diagnostic orbit | learned Gaussians','Recorded camera path, 512 x 384 native rendering. 72 unique poses.')
    panel(image,Image.open(native/f'orbit_{i:03}.png'),(96,149,768,486))
    emit(image,2)
for i,progress in enumerate([0,0.65,0.85,1]):
    image=base(f'Representative portfolio camera | progress {progress:.2f}',
        '640 x 360 native render. Patch-only framing; house, river, occlusion and integration absent.')
    panel(image,Image.open(native/f'journey_{i:03}.png'),(30,150,900,486))
    emit(image,24)
for i in range(4):
    image=base(f'Held-out camera {i+1} | reference and learned comparison',
        'Four unseen views: mean native PSNR 32.36 dB, SSIM 0.908. Images enlarged for display.')
    draw=ImageDraw.Draw(image)
    draw.text((60,166),'Cycles reference',font=font(22),fill='white')
    draw.text((526,166),'Learned Gaussians',font=font(22),fill='white')
    panel(image,reference(source/f'dataset/images/val_{i:03}.png'),(35,205,425,410))
    panel(image,Image.open(root/f'outputs/train-2000/training/eval_2000/val_{i:03}.png'),(500,205,425,410))
    emit(image,12)
assert index==288
(out/'video-layout.json').write_text(json.dumps({'encoded_frames':288,'fps':24,'seconds':12,
    'orbit_unique_views':72,'orbit_seconds':6,'journey_views':4,'journey_seconds':4,
    'heldout_comparison_views':4,'heldout_comparison_seconds':2,
    'renderer':'Official Brush v0.3.0 on Metal; display enlargement only; no Blender render presented as learned.'},indent=2))
print('Created comparison, preserved original PLY, and composed',index,'preview frames.')
