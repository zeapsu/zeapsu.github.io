# Learned terrain result

Real Gaussian-splat training completed on the MacBook Air M4 using the official,
checksum-verified Brush v0.3.0 Apple Silicon binary and Metal. The retained PLY
is the original 2,000-step learned export, with 12,000 finite Gaussian records.
The seed geometry and Blender reference footage are separate input artifacts.

## Files

- `terrain-trained-2000.ply`: unchanged native learned export, 672,435 bytes.
- `terrain-learned-preview.mp4`: 12-second H.264 video, 960 x 720, 24 encoded
  frames per second. The first six seconds show 72 recorded orbit poses rendered
  by Brush at 512 x 384. Four representative portfolio cameras follow for four
  seconds, rendered at 640 x 360. The final two seconds compare four held-out
  reference images with learned splats. Video display enlargement does not add
  detail to the training captures, and encoded frame rate is not viewer speed.
- `terrain-heldout-comparison.png`: Cycles reference, two-step pilot, and final
  learned renders for all four held-out cameras. Sources are 192 x 192.
- `metrics.json`: native checkpoint quality, independent PNG pixel losses, and
  resource measurements.
- `render-verification.json`: learned parameter and reload-render preservation.
- `evidence/`: commands, logs, monitors, camera definitions, source identity,
  and the scoped reproduction scripts. The private input archive remains a
  separate Library artifact.

## Measured result

The two-step pilot completed on Apple M4/Metal, produced a learned PLY, and
achieved mean held-out PSNR 15.962137 dB and SSIM 0.5942214. The fresh 2,000-step
run used 24 training images, four held-out images, SH degree 0, resolution 192,
seed 42, refinement every 50 iterations, and a 12,000-splat cap. Growth stopped
at iteration 1,500. Final mean held-out PSNR was 32.364735 dB and SSIM 0.9076311.

Mean RGB L1 loss from the quantized held-out PNGs, composited over black, fell
from 0.0951216 in the pilot to 0.0117350 after training. Native PSNR/SSIM use
unquantized renderer output. PNG-derived metrics differ slightly due to byte
quantization. Background pixels are included; per-view foreground L1 losses
are also recorded. The headless CLI did not emit scalar optimization loss, so
there is no claimed training-objective loss curve.

Brush reported 12 seconds of training, rounded to whole seconds. The supervisor
finished after 15.32 seconds, including polling. Sampled trainer process RSS
peaked at 149,880,832 bytes. This excludes unaccounted GPU/driver allocations.
System memory-free percentage stayed at or above 34%, thermal state stayed
nominal, AC remained connected, and disk free stayed above 16.24 billion bytes.
No resource stop triggered. The 180-second deadline and scoped termination
were active. All scoped process groups exited.

## Learned-model rendering verification

Brush's evaluation renderer produced 81 recorded-camera views from a copy of
the learned PLY. A one-step pass triggers evaluation with zero color, opacity,
and rotation learning rates, mean/scale learning rates of 1e-30, zero noise,
and no refinement. Means, log scales, colors, and opacities remained bit-exact.
Quaternion export normalization differed by at most 2.38419e-7. Reloaded held-out
renders differed by at most one uint8 channel level. The retained deliverable
is the original training export, not the follow-up rendering export.

The first rendering attempt failed because Brush v0.3.0 reads exactly 16,387
initial bytes while probing image metadata. The small compressed placeholder
PNGs used only for orbit camera dimensions were shorter. Lossless uncompressed
PNG encoding resolved the failure. The learned binary PLY reloaded correctly
in a direct test. Placeholder aggregate evaluation metrics are excluded from
quality reporting because those placeholders are not reference images.

## Limits and coordinates

This is a 2.8-metre synthetic grass/dirt/rock patch, trained from 192-pixel
images. Fine grass and granular dirt are softer than the Cycles references.
SH0 gives view-independent color. Four held-out cameras from the same synthetic
capture are a small validation set, not evidence of real-world reconstruction.

The recorded portfolio cameras show only the isolated patch. The distant view
makes it small, and the approach partly crops it. House, river, full-scene
occlusion, mobile framing, bank fitting, and site integration remain untested.
Training and rendering were isolated from the portfolio site. Site integration remains untested.

Geometry retains the Blender-local coordinates of the supplied dataset,
with Z as the physical vertical axis. Brush's exporter writes a generic
`Vertical axis: y` comment without transforming coordinates. The PLY is retained
unchanged for provenance. A later viewer/integration should use the supplied
camera matrices and coordinate mapping rather than assuming that comment is
the geometry's actual axis. The documented candidate Three.js placement is
`Three = (local.x + 3.5, local.z - 0.32, -local.y + 7.3)`.

## Provenance

Source captures are retained separately; their archive hash is below.
Input archive SHA-256:
`2a7465cedd7d9f110f08e9b4833b6e12f74331599e620d3acf54e8d39602ac19`.
All 73 manifest-listed input files passed size and hash validation.

Official software/source:
[Brush v0.3.0 release](https://github.com/ArthurBrussee/brush/releases/tag/v0.3.0),
[pinned renderer/trainer](https://github.com/ArthurBrussee/brush/tree/3edecbb2fe79d3e2c87eeab85b15e0b1dd10d486),
[image metadata reader](https://github.com/ArthurBrussee/brush/blob/3edecbb2fe79d3e2c87eeab85b15e0b1dd10d486/crates/brush-dataset/src/scene.rs),
[PLY export](https://github.com/ArthurBrussee/brush/blob/3edecbb2fe79d3e2c87eeab85b15e0b1dd10d486/crates/brush-serde/src/export.rs).

## Publication copy

Local account paths use `$WORKSPACE`, and the internal Library identifier is omitted.
See `publication-note.json` for the original archive hash and metadata edits.
The learned PLY, video, every image, metric values, and camera matrices are unchanged.
