import Foundation
import Metal

let process = ProcessInfo.processInfo
print("thermalState=\(process.thermalState.rawValue)")
print("physicalMemory=\(process.physicalMemory)")
for device in MTLCopyAllDevices() {
    print("device=\(device.name)")
    print("isLowPower=\(device.isLowPower)")
    print("hasUnifiedMemory=\(device.hasUnifiedMemory)")
    print("maxThreadsPerThreadgroup=\(device.maxThreadsPerThreadgroup)")
    print("recommendedMaxWorkingSetSize=\(device.recommendedMaxWorkingSetSize)")
    print("currentAllocatedSize=\(device.currentAllocatedSize)")
}
