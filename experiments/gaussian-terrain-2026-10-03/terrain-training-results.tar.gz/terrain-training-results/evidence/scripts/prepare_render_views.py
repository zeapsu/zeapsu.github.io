"""Prepare known camera poses to render a learned PLY using Brush's eval output."""
import copy
import json
import shutil
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
source = root / 'inputs/gaussian-terrain-reference'
destination = root / 'outputs/render-dataset'
destination.mkdir(exist_ok=False)
(destination / 'images').mkdir()
shutil.copy2(root / 'outputs/train-2000/training/export_2000.ply', destination / 'init.ply')
train = json.loads((source / 'dataset/transforms_train.json').read_text())
train['frames'] = train['frames'][:1]
shutil.copy2(source / 'dataset/images/train_000.png', destination / 'images/train_000.png')
(destination / 'transforms_train.json').write_text(json.dumps(train, indent=2))
views = []
manifest = []
def add_view(frame, name, reference=None):
    frame = copy.deepcopy(frame)
    frame['file_path'] = 'images/' + name + '.png'
    path = destination / frame['file_path']
    if reference:
        shutil.copy2(reference, path)
    else:
        # Brush v0.3.0's metadata probe reads exactly 16,387 initial bytes.
        # Uncompressed PNG keeps tiny placeholder pixels valid for that reader.
        Image.new('RGBA', (frame['w'], frame['h']), (0, 0, 0, 0)).save(path, compress_level=0)
    views.append(frame)
    manifest.append({'name': name, 'reference': str(reference) if reference else None,
                     'camera': frame})

val = json.loads((source / 'dataset/transforms_val.json').read_text())
for i, frame in enumerate(val['frames']):
    add_view(frame, f'holdout_{i:03}', source / 'dataset' / frame['file_path'])
clip = json.loads((source / 'clip-camera-poses.json').read_text())
for i, frame in enumerate(clip['frames']):
    add_view(frame, f'orbit_{i:03}')
representative = json.loads((source / 'representative-poses.json').read_text())
for i, frame in enumerate(representative['frames']):
    add_view(frame, f'journey_{i:03}', source / frame['file_path'])
add_view(representative['overview'], 'overview', source / representative['overview']['file_path'])
(destination / 'transforms_val.json').write_text(json.dumps({'camera_model':'OPENCV','frames':views},indent=2))
(destination / 'render-manifest.json').write_text(json.dumps({'views':manifest,
    'note':'Orbit placeholders supply dimensions for Brush evaluation rendering; their evaluation metrics are not ground-truth quality metrics.'},indent=2))
print('Prepared', len(views), 'known-camera views. Training split contains one original image only.')
