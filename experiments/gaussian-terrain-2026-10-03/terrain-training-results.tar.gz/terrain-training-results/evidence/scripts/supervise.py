"""Run only this task's process group with a deadline and Mac resource stops."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
import re
import signal
import shutil
import subprocess
import threading
import time
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--output', type=Path, required=True)
p.add_argument('--seconds', type=int, required=True)
p.add_argument('--probe', type=Path, required=True)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
cmd = a.command[1:] if a.command[:1] == ['--'] else a.command
assert cmd and a.seconds > 0
a.output.mkdir(parents=True, exist_ok=False)

def output(command):
    return subprocess.check_output(command, text=True, timeout=2)

def sample(root_pid=None):
    commands = [[str(a.probe.resolve())], ['/usr/bin/memory_pressure', '-Q'], ['/usr/bin/pmset', '-g', 'batt']]
    if root_pid:
        commands.append(['/bin/ps', '-axo', 'pid=,ppid=,rss='])
    with ThreadPoolExecutor(max_workers=4) as pool:
        readings = list(pool.map(output, commands))
    probe, pressure, battery = readings[:3]
    thermal_match = re.search(r'^thermalState=(\d+)$', probe, re.M)
    assert thermal_match, 'thermal monitoring unavailable'
    thermal = int(thermal_match.group(1))
    pressure_match = re.search(r'System-wide memory free percentage: (\d+)%', pressure)
    assert pressure_match, 'memory monitoring unavailable'
    free_pct = int(pressure_match.group(1))
    on_ac = "Now drawing from 'AC Power'" in battery
    disk_free = shutil.disk_usage(a.output).free
    rss = 0
    pids = []
    if root_pid:
        rows = [tuple(map(int, line.split())) for line in readings[3].splitlines() if line.strip()]
        pids = [root_pid]
        changed = True
        while changed:
            added = [pid for pid, parent, _ in rows if parent in pids and pid not in pids]
            changed = bool(added)
            pids.extend(added)
        rss = sum(kib * 1024 for pid, _, kib in rows if pid in pids)
    result = dict(time=time.time(), thermal_state=thermal, memory_free_pct=free_pct,
                  on_ac=on_ac, disk_free_bytes=disk_free, group_rss_bytes=rss, scoped_pids=pids)
    stop = None
    if thermal >= 2:
        stop = 'thermal serious or critical'
    elif not on_ac:
        stop = 'AC disconnected'
    elif free_pct < 15:
        stop = 'memory free below 15 percent'
    elif rss > 3 * 1024**3:
        stop = 'scoped process RSS above 3 GiB'
    elif disk_free < 4 * 1024**3:
        stop = 'disk free below 4 GiB'
    return result, stop

def stop_group(proc):
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    proc.wait(timeout=5)
    try:
        os.killpg(proc.pid, 0)
    except ProcessLookupError:
        return True
    return False

start = time.monotonic()
reason = None
proc = None
confirmed_exit = True
deadline_hit = threading.Event()
deadline_timer = None
def expire():
    deadline_hit.set()
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
with (a.output / 'monitor.jsonl').open('w') as log:
    try:
        row, reason = sample()
        log.write(json.dumps(row) + '\n'); log.flush()
        if reason:
            raise RuntimeError(reason)
        with (a.output / 'supervisor.log').open('w') as trainer_log:
            proc = subprocess.Popen(cmd, stdout=trainer_log, stderr=subprocess.STDOUT,
                                    start_new_session=True, preexec_fn=lambda: os.nice(10))
            deadline_timer = threading.Timer(a.seconds, expire)
            deadline_timer.start()
            while True:
                sample_started = time.monotonic()
                row, reason = sample(proc.pid)
                row['elapsed_seconds'] = time.monotonic() - start
                log.write(json.dumps(row) + '\n'); log.flush()
                if deadline_hit.is_set():
                    reason = 'supervisor deadline'
                if reason:
                    break
                if proc.poll() is not None:
                    break
                if time.monotonic() - start >= a.seconds:
                    reason = 'supervisor deadline'
                    break
                time.sleep(max(0.1, 5 - (time.monotonic() - sample_started)))
    except BaseException as e:
        reason = f'{type(e).__name__}: {e}'
    finally:
        if deadline_timer:
            deadline_timer.cancel()
        if proc:
            confirmed_exit = stop_group(proc)
report = dict(command=cmd, exit_code=proc.returncode if proc else None,
              stop_reason=reason, elapsed_seconds=time.monotonic() - start,
              scoped_group_confirmed_exited=confirmed_exit)
(a.output / 'supervisor-report.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
raise SystemExit(0 if proc and proc.returncode == 0 and not reason and confirmed_exit else 1)
